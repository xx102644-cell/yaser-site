// script.js

(function() {
    // عناصر الشاشات
    const welcomeScreen = document.getElementById('welcome-screen');
    const giftScreen = document.getElementById('gift-screen');
    const subscribeScreen = document.getElementById('subscribe-screen');
    const registerScreen = document.getElementById('register-screen');
    const shareScreen = document.getElementById('share-screen');
    const bonusScreen = document.getElementById('bonus-screen'); // جديدة

    // أزرار التنقل
    const startBtn = document.getElementById('start-contest');
    const backFromGift = document.getElementById('back-from-gift');
    const backFromSubscribe = document.getElementById('back-from-subscribe');
    const backFromRegister = document.getElementById('back-from-register');
    const backFromShare = document.getElementById('back-from-share');
    const restartBtn = document.getElementById('restart-btn'); // من شاشة الجائزة

    // صناديق الهدايا
    const giftBoxes = document.querySelectorAll('.gift-box');
    const giftMessage = document.getElementById('gift-message');

    // الاشتراك
    const subscribeLinkDiv = document.getElementById('subscribe-link');

    // التسجيل
    const fullNameInput = document.getElementById('fullname');
    const emailInput = document.getElementById('email');
    const mobileInput = document.getElementById('mobile');
    const registerBtn = document.getElementById('register-btn');
    const validationIcon = document.getElementById('register-validation');

    // مشاركة
    const shareCountSpan = document.getElementById('share-count');
    const shareButtons = document.querySelectorAll('.share-btn'); // جميع أزرار المشاركة

    // متغيرات الحالة المحفوظة في localStorage
    let selectedGift = localStorage.getItem('selectedGift') || null;
    let hasSubscribed = localStorage.getItem('hasSubscribed') === 'true';
    let userData = JSON.parse(localStorage.getItem('userData'));
    let shareCount = parseInt(localStorage.getItem('shareCount') || '0', 10);

    // وظيفة لعرض شاشة معينة وإخفاء الباقي
    function showScreen(screenId) {
        [welcomeScreen, giftScreen, subscribeScreen, registerScreen, shareScreen, bonusScreen].forEach(s => s.classList.add('hidden'));
        document.getElementById(screenId).classList.remove('hidden');
    }

    // تحديث عداد المشاركات في الواجهة
    function updateShareCounter() {
        if (shareCountSpan) {
            shareCountSpan.textContent = shareCount;
        }
    }

    // دالة لزيادة عدد المشاركات (تستدعى عند النقر على زر مشاركة)
    function incrementShareCount() {
        if (shareCount < 20) {
            shareCount++;
            localStorage.setItem('shareCount', shareCount);
            updateShareCounter();

            // إذا وصلنا إلى 20، ننتقل إلى شاشة الجائزة
            if (shareCount === 20) {
                // تأخير بسيط حتى يرى المستخدم العداد 20/20 ثم ينتقل
                setTimeout(() => {
                    showScreen('bonus-screen');
                }, 500);
            }
        }
    }

    // تحديد الشاشة الابتدائية بناءً على التخزين المحلي
    function determineInitialScreen() {
        if (shareCount >= 20) {
            // إذا كان قد أكمل المشاركات من قبل، اعرض شاشة الجائزة
            showScreen('bonus-screen');
        } else if (userData && userData.fullname && userData.email && userData.mobile) {
            showScreen('share-screen');
            updateShareCounter();
        } else if (hasSubscribed) {
            showScreen('register-screen');
        } else if (selectedGift) {
            showScreen('subscribe-screen');
        } else {
            showScreen('welcome-screen');
        }
    }

    // حفظ حالة الهدية المختارة والانتقال للاشتراك
    function handleGiftClick(e) {
        const box = e.currentTarget;
        const giftName = box.getAttribute('data-gift');
        localStorage.setItem('selectedGift', giftName);
        selectedGift = giftName;

        giftMessage.innerHTML = `🎉 ألف مبروك! ربحت ${giftName} 🎉`;

        setTimeout(() => {
            showScreen('subscribe-screen');
        }, 1200);
    }

    // ربط الصناديق
    giftBoxes.forEach(box => box.addEventListener('click', handleGiftClick));

    // بدء المسابقة من الترحيب
    startBtn.addEventListener('click', () => {
        showScreen('gift-screen');
        giftMessage.innerHTML = '✨ اختر صندوقاً لتربح جائزتك ✨';
    });

    // أزرار الرجوع
    backFromGift.addEventListener('click', () => showScreen('welcome-screen'));
    backFromSubscribe.addEventListener('click', () => showScreen('gift-screen'));
    backFromRegister.addEventListener('click', () => showScreen('subscribe-screen'));
    backFromShare.addEventListener('click', () => showScreen('register-screen'));

    // إعادة التشغيل من شاشة الجائزة
    restartBtn.addEventListener('click', () => {
        // مسح جميع البيانات (اختياري) أو إبقائها؟ سنمسح لنبدأ جديد
        localStorage.clear();
        // إعادة تعيين المتغيرات
        selectedGift = null;
        hasSubscribed = false;
        userData = null;
        shareCount = 0;
        // تحديث الواجهة
        updateShareCounter();
        showScreen('welcome-screen');
    });

    // منطق الاشتراك
    subscribeLinkDiv.addEventListener('click', function() {
        window.open('https://www.youtube.com/@powerboardpro', '_blank');
        localStorage.setItem('hasSubscribed', 'true');
        hasSubscribed = true;
        showScreen('register-screen');
    });

    // التحقق من اكتمال بيانات التسجيل
    function checkRegisterForm() {
        const name = fullNameInput.value.trim();
        const email = emailInput.value.trim();
        const mobile = mobileInput.value.trim();

        if (name !== '' && email !== '' && mobile !== '') {
            validationIcon.innerHTML = '<i class="fas fa-check-circle fa-2x" style="color:#2ecc71;"></i>';
            return true;
        } else {
            validationIcon.innerHTML = '<i class="fas fa-times-circle fa-2x" style="color:#e74c3c;"></i>';
            return false;
        }
    }

    [fullNameInput, emailInput, mobileInput].forEach(input => {
        input.addEventListener('input', checkRegisterForm);
    });

    // زر تسجيل البيانات
    registerBtn.addEventListener('click', function() {
        const name = fullNameInput.value.trim();
        const email = emailInput.value.trim();
        const mobile = mobileInput.value.trim();

        if (name === '' || email === '' || mobile === '') {
            validationIcon.innerHTML = '<i class="fas fa-times-circle fa-2x" style="color:#e74c3c;"></i> البيانات ناقصة ❌';
            return;
        }

        const user = { fullname: name, email: email, mobile: mobile };
        localStorage.setItem('userData', JSON.stringify(user));
        userData = user;

        validationIcon.innerHTML = '<i class="fas fa-check-circle fa-2x" style="color:#2ecc71;"></i> تم التسجيل بنجاح ✅';

        setTimeout(() => {
            showScreen('share-screen');
            updateShareCounter(); // عند الانتقال لمشاركة، نحدث العداد
        }, 800);
    });

    // تجهيز روابط المشاركة وربط حدث زيادة العداد
    function setShareLinks() {
        const contestLink = 'https://ramadan-contest.com'; // رابط وهمي
        const shareText = 'اشترك في مسابقة رمضان الكبرى واربح 1000$ أو iPhone 17 Pro! 🎁';
        const encodedText = encodeURIComponent(shareText);
        const encodedLink = encodeURIComponent(contestLink);

        // روابط المشاركة (تظل كما هي)
        const waBtn = document.getElementById('share-wa');
        const fbBtn = document.getElementById('share-fb');
        const twBtn = document.getElementById('share-tw');
        const tgBtn = document.getElementById('share-tg');
        const inBtn = document.getElementById('share-in');

        waBtn.href = `https://wa.me/?text=${encodedText}%20${encodedLink}`;
        fbBtn.href = `https://www.facebook.com/sharer/sharer.php?u=${encodedLink}&quote=${encodedText}`;
        twBtn.href = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedLink}`;
        tgBtn.href = `https://t.me/share/url?url=${encodedLink}&text=${encodedText}`;
        inBtn.href = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedLink}`;

        // إضافة مستمع لكل زر لزيادة العداد عند النقر (مع فتح الرابط)
        shareButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                // لا نمنع الافتراض كلياً لأننا نريد فتح الرابط، لكن نمنعه لحظياً ثم نعيد التوجيه
                e.preventDefault();
                // زيادة العداد إذا لم نصل 20
                incrementShareCount();
                // بعد ثانية افتح الرابط (حتى يرى المستخدم العداد)
                setTimeout(() => {
                    window.open(btn.href, '_blank');
                }, 100);
            });
        });
    }

    // تنفيذ عند تحميل الصفحة
    window.addEventListener('load', function() {
        if (userData) {
            fullNameInput.value = userData.fullname || '';
            emailInput.value = userData.email || '';
            mobileInput.value = userData.mobile || '';
            checkRegisterForm();
        }
        // تحديث العداد في الواجهة
        updateShareCounter();
        determineInitialScreen();

        if (!giftScreen.classList.contains('hidden') && selectedGift) {
            giftMessage.innerHTML = `🎉 سبق وربحت ${selectedGift} 🎉`;
        }
    });

    // مراقبة ظهور شاشة الهدايا لعرض رسالة سابقة
    const observer = new MutationObserver(() => {
        if (!giftScreen.classList.contains('hidden') && selectedGift) {
            giftMessage.innerHTML = `🎉 لقد ربحت سابقاً: ${selectedGift} 🎉 يمكنك الاشتراك لتسجيل البيانات`;
        }
    });
    observer.observe(giftScreen, { attributes: true, attributeFilter: ['class'] });

    // مراقبة ظهور شاشة الاشتراك للتأكد من اختيار هدية
    const subObserver = new MutationObserver(() => {
        if (!subscribeScreen.classList.contains('hidden')) {
            const currentSelected = localStorage.getItem('selectedGift');
            if (!currentSelected) {
                showScreen('gift-screen');
                alert('الرجاء اختيار صندوق هدية أولاً');
            }
        }
    });
    subObserver.observe(subscribeScreen, { attributes: true, attributeFilter: ['class'] });

    // مراقبة ظهور شاشة التسجيل للتأكد من الاشتراك
    const regObserver = new MutationObserver(() => {
        if (!registerScreen.classList.contains('hidden')) {
            const subscribed = localStorage.getItem('hasSubscribed') === 'true';
            if (!subscribed) {
                showScreen('subscribe-screen');
                alert('يجب الاشتراك في القناة أولاً');
            }
        }
    });
    regObserver.observe(registerScreen, { attributes: true, attributeFilter: ['class'] });

    // استدعاء دالة تجهيز روابط المشاركة
    setShareLinks();
})();